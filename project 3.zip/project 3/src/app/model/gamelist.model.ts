export class Gamelists { 
    
     game_name?: string;
      game_price?: number; 
     
    }