package com.bankproject.exception;

public class BankException extends Exception{
	
	public BankException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BankException(String msg){
		super(msg);
	}
}
