package com.bankproject.util;

import java.util.HashMap;
import java.util.Map;

import com.bankproject.bean.Account;

public class BankUtil {

	static Map<Integer,Account> accountMap = new HashMap<Integer, Account>();
	
	public static Map<Integer,Account> getAccountList(){
		return accountMap;
	}
}
