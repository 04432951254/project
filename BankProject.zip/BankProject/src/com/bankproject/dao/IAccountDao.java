package com.bankproject.dao;

import java.util.Collection;

import com.bankproject.bean.Account;
import com.bankproject.exception.BankException;

public interface IAccountDao {

	int createAccount(Account acc);

	Account showBalance(int accid) throws BankException;

	Account deposit(int accid, long amount) throws BankException;

	Account withDraw(int accid, long amount) throws BankException;

	Account transferFund(int accid, long amount) throws BankException;

	Collection<Account> getAllTransaction() throws BankException;

}
