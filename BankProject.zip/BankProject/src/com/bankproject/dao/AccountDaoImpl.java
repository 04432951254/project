package com.bankproject.dao;

import java.util.Collection;

import com.bankproject.bean.Account;
import com.bankproject.exception.BankException;
import com.bankproject.util.BankUtil;

public class AccountDaoImpl implements IAccountDao {

	//creating an account
	@Override
	public int createAccount(Account acc) {
		BankUtil.getAccountList().put(acc.getAccountId(), acc);
		return acc.getAccountId();
	}

	//showing paricular account balance
	@Override
	public Account showBalance(int accid) throws BankException {
		if((BankUtil.getAccountList().containsKey(accid))==false)
			throw new BankException("Account Id does not exist in Bank details");
		return BankUtil.getAccountList().get(accid);
	}

	//depositing amount into the particular account
	@Override
	public Account deposit(int accid,long amount) throws BankException {
		Account acc=null;
		if((BankUtil.getAccountList().containsKey(accid))==false)
			throw new BankException("Account Id does not exist in Bank details");
		else{
			acc = BankUtil.getAccountList().get(accid);
			long balance=acc.getBalance();
			balance+=amount;
			acc.setOpeningBalance(balance);
		}
		return acc;
	}

	//withdrawing amount from the account
	@Override
	public Account withDraw(int accid, long amount) throws BankException {
		Account acc=null;
		if(amount>=(BankUtil.getAccountList().get(accid).getBalance()-500))
			throw new BankException("Amount is greater than the balance");
		else if(amount<0)
			throw new BankException("Amount should be greater than zero");
		else{
			acc = BankUtil.getAccountList().get(accid);
			long balance=acc.getBalance();
			balance-=amount;
			System.out.println(balance);
			acc.setOpeningBalance(balance);}
		return acc;
	}

	//transfering amount from the account
	@Override
	public Account transferFund(int accid, long amount) throws BankException {
		Account acc=null;
		if(amount>=(BankUtil.getAccountList().get(accid).getBalance()-500))
			throw new BankException("Amount is greater than the balance");
		else if(amount<0)
			throw new BankException("Amount should be greater than zero");
		else{
			acc = BankUtil.getAccountList().get(accid);
			long balance=acc.getBalance();
			balance-=amount;
			acc.setOpeningBalance(balance);}
		return acc;
	}

	//getting all transaction details
	@Override
	public Collection<Account> getAllTransaction() throws BankException {
		if(BankUtil.getAccountList().isEmpty())
			throw new BankException("No account exists in Bank");
		return BankUtil.getAccountList().values();
	}

}
