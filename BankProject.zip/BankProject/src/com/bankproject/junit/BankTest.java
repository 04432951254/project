package com.bankproject.junit;

import junit.framework.Assert;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bankproject.bean.Account;
import com.bankproject.dao.AccountDaoImpl;
import com.bankproject.dao.IAccountDao;
import com.bankproject.exception.BankException;


public class BankTest {

	private static IAccountDao idao=null;
	
	@Before
	public void init(){
		idao=new AccountDaoImpl();
	}
	
	@After
	public void destroy(){
		idao=null;
	}
	
	//create Account
	@Test
	public void createAccount(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		Assert.assertEquals(1001, idao.createAccount(acc));
	}
	
	//showBalance
	@Test
	public void showBalance(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		idao.createAccount(acc);
		try {
			Assert.assertEquals(5000, idao.showBalance(1001).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//DepositAmount
	@Test
	public void depositAmount(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		idao.createAccount(acc);
		try {
			Assert.assertEquals(6000, idao.deposit(1001, 1000).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Withdraw amount
	@Test
	public void withDrawAmount(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		idao.createAccount(acc);
		try {
			Assert.assertEquals(3000, idao.withDraw(1001, 2000).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
	
	//Transfer fund
	@Test
	public void transferFund(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		idao.createAccount(acc);
		try {
			Assert.assertEquals(4000, idao.transferFund(1001, 1000).getBalance());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}

	//Get all transaction
	@Test
	public void getAllTransaction(){
		Account acc = new Account("Chaitra", "7896541230", "chaitra@gmail.com", "ABC7896542", "savings", 5000, "Bangalore");
		acc.setAccountId(1001);
		idao.createAccount(acc);
		try {
			Assert.assertNotNull(idao.getAllTransaction());
		} catch (BankException e) {
			System.out.println(e.getMessage());
		}
	}
}
