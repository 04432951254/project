package com.bankproject.service;

import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bankproject.bean.Account;
import com.bankproject.dao.AccountDaoImpl;
import com.bankproject.dao.IAccountDao;
import com.bankproject.exception.BankException;

public class AccountServiceImpl implements IAccountService{

	
	static Matcher m = null;
	static IAccountDao accd=null;
	
	//validating Account holder name
	@Override
	public boolean validateName(String name) throws BankException {
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(!m.find())
			throw new BankException("Name is not matching");
		return true;
	}

	//validating Account holder mobile number
	@Override
	public boolean validateMob(String mob) throws BankException {
		m=Pattern.compile("^[6789]([0-9]){9}$").matcher(mob);
		if(!m.find())
			throw new BankException("This number is not valid");
		return true;
	}

	//validating Account holder email id
	@Override
	public boolean validateEmail(String email) throws BankException {
		m=Pattern.compile("^([a-zA-Z0-9.]){6,}@gmail.com$").matcher(email);
		if(!m.find())
			throw new BankException("This email id is not valid");
		return true;
	}

	//validating Account holder pan number
	@Override
	public boolean validatePan(String pan) throws BankException {
		m=Pattern.compile("^([A-Z0-9]){10}$").matcher(pan);
		if(!m.find())
			throw new BankException("This pan number is not valid");
		return true;
	}

	//validating Account holder accountType
	@Override
	public boolean validateAccType(String accType) throws BankException {
		if(accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
			return true;
		throw new BankException("This pan number is not valid");
	}

	//validating Account holder account balance
	@Override
	public boolean validateAmount(long amount) throws BankException {
		if(amount<500)
			throw new BankException("Amount should be greater than or equal to 500");
		return true;
	}
	
	//creating an account
	@Override
	public int creatAccount(Account acc) {
		accd=new AccountDaoImpl();
		acc.setAccountId(generateaAccId());
		return accd.createAccount(acc);
	}

	//generating account id
	private int generateaAccId() {
		// TODO Auto-generated method stub
		return (int)(Math.random()*1000);
	}

	//showing particular account balance
	@Override
	public Account showBalance(int accid) throws BankException {
		accd=new AccountDaoImpl();
		return accd.showBalance(accid);
	}

	//depositing amount to the particular account
	@Override
	public Account deposit(int accid, long amount) throws BankException {
		accd=new AccountDaoImpl();
		return accd.deposit(accid,amount);
	}

	//withdrawing amount
	@Override
	public Account withDraw(int accid, long amount) throws BankException {
		accd=new AccountDaoImpl();
		return accd.withDraw(accid,amount);
	}

	//transfering fund
	@Override
	public Account transferFund(int accid, long amount) throws BankException {
		accd=new AccountDaoImpl();		
		return accd.transferFund(accid,amount);
	}

	//getting all transactions
	@Override
	public Collection<Account> getAllTransaction() throws BankException {
		accd=new AccountDaoImpl();
		return accd.getAllTransaction();
	}

}
