package com.bankproject.service;

import java.util.Collection;

import com.bankproject.bean.Account;
import com.bankproject.exception.BankException;

public interface IAccountService {

	boolean validateName(String name) throws BankException;

	boolean validateMob(String mob) throws BankException;

	boolean validateEmail(String email) throws BankException;

	boolean validatePan(String pan) throws BankException;

	boolean validateAccType(String accType) throws BankException;

	boolean validateAmount(long amount) throws BankException;

	int creatAccount(Account acc);

	Account showBalance(int accid) throws BankException;

	Account deposit(int accid, long amount) throws BankException;

	Account withDraw(int accid, long amount) throws BankException;

	Account transferFund(int accid, long amount) throws BankException;

	Collection<Account> getAllTransaction() throws BankException;

}
