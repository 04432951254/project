package com.capgemini.hotel.util;

import java.util.HashMap;
import java.util.Map;

public class Hotelutil {

	public static Map<String, String>roomDetails = new HashMap<String,String>();

	public static Map<String, String> getRoomCategoryEntries() {
		roomDetails.put("101", "AC_ROOM");
		roomDetails.put("102", "AC_SINGLE");
		roomDetails.put("103", "AC_DOUBLE");
		roomDetails.put("201", "NONAC_SINGLE");
		roomDetails.put("202", "NONAC_SINGLE");
		roomDetails.put("203", "NONAC_DOUBLE");
		return roomDetails;
	
	}
	
	
}
