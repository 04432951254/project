package com.capgemini.hotel.ui;

import java.util.Collection;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelException;
import com.capgemini.hotel.service.Hotelservice;
import com.capgemini.hotel.service.IHotelservice;





public class Client {
	
	static Scanner scan = new Scanner(System.in);
	 static  IHotelservice iser=null;
	 boolean res=false;
		public static CustomerBean r=null;

		public static void main(String[] args) throws HotelException {

			String h = null;

			do {

				System.out.println("Select the your option");
				System.out.println("1. Book Room\n 2.viewroomdetails\n 3. Exit Id");
				int n = scan.nextInt();
				switch (n) {
				case 1:
					Bookroom();
					break;
				case 2:
					System.out.println("Enter the id");
					int id = scan.nextInt();
					CustomerBean r = viewroomdetails(id);
					
					System.out.println("NAME of the customer : "+r.getName());
					System.out.println("Mobile number of the customer : "+r.getMob());
					
					break;
			
				
				

				case 3:
					System.out.println("Program Terminated");
					System.exit(0);
					break;
				default:
					System.out.println("choose your proper choice from 1-3");
					n = scan.nextInt();
					break;
				}
				System.out.println("do you want to continue y/n");
				h = scan.next();
				if (h.equalsIgnoreCase(h)) {
					System.out.println("Program Terminated");
				}
			} while (h.equalsIgnoreCase("y"));

		}








		private static CustomerBean viewroomdetails(int id) {
			IHotelservice iserv = null;
			iserv = new Hotelservice();
			return iserv.viewroomdetails(id);
		}












		

		private static void Bookroom() throws HotelException {
			String roomCategoryID = "";
			IHotelservice iserv = null;
			iserv = new Hotelservice();
			List<RoomBooking> RoomCategoryList = iserv.roomDetails();
			int n = 1;
			for (RoomBooking RoomCategoryName : RoomCategoryList) {
				System.out.println(String.valueOf(n) + ". " + RoomCategoryName);
				n++;
			}
			System.out.print("\nEnter option : ");
			try {
				switch (Integer.parseInt(scan.next().trim())) {
				case 1:
					roomCategoryID  = RoomCategoryList.get(0).getRoomid();
					break;
				case 2:
					roomCategoryID  = RoomCategoryList.get(1).getRoomid();
					break;
				case 3:
					roomCategoryID = RoomCategoryList.get(2).getRoomid();
					break;
				case 4:
					roomCategoryID = RoomCategoryList.get(3).getRoomid();
					break;
				case 5:
					roomCategoryID = RoomCategoryList.get(4).getRoomid();
					break;
				case 6:
					roomCategoryID = RoomCategoryList.get(5).getRoomid();
					break;
				
				

				default:
					System.out.println("please enter the correct option");
					System.exit(-1); // Exits out of the application if wrong option is selected.
				}
			} catch (Exception e) {
				System.out.println("Enter only number");
				System.exit(-1); // Exits out of the application if char is entered instead of a number.
			}
			System.out.println("enter name");
			String name = scan.next();
			
			System.out.println("enter phone");
			String mob = scan.next();
			iserv.validateMob(mob);
			System.out.println("enter address");
			String address = scan.next();
			System.out.println("enter mail");
			String mail = scan.next();
			System.out.println("enter roomid");
			String roomid = scan.next();
			System.out.println("enter roomtype");
			String roomtype = scan.next();
			
		


			CustomerBean bean = new CustomerBean(name,  mail,  address,  mob);
              RoomBooking room = new RoomBooking(roomid,roomtype);
			iserv = new Hotelservice();
			try {
				iserv.addCustomerDetails(bean);
				
			} catch (HotelException e) {
				System.out.println(e);
			}
		}
	}


