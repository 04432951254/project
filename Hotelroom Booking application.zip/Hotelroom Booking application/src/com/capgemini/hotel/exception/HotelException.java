package com.capgemini.hotel.exception;

public class HotelException   extends Exception{

	public HotelException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HotelException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
