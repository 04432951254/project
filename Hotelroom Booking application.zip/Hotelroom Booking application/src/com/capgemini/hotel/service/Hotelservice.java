package com.capgemini.hotel.service;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;
import com.capgemini.hotel.dao.ICustomerBookingDAO;
import com.capgemini.hotel.exception.HotelException;








public class Hotelservice implements IHotelservice {

	ICustomerBookingDAO idao = null;
	static Matcher m= null;
	
	private String generateCustomerID() {
		return String.valueOf((int) (Math.random() * 10000));
	}
	
	
	@Override
	public boolean addCustomerDetails(CustomerBean bean) throws HotelException {
		bean.setCustomerid(generateCustomerID());
		bean.setDate(LocalDate.now());
		idao = new CustomerBookingDAO();
		return idao.addCustomerDetails(bean);
		
		
		
	}

	
	
	
	
	@Override
	public List<RoomBooking> roomDetails() throws HotelException {
		idao = new CustomerBookingDAO();
		return idao.roomDetails();
	}

	@Override
	public CustomerBean viewroomdetails(int id) {
		idao = new CustomerBookingDAO();
		return idao.viewroomdetails(id);
	}

	@Override
	public boolean validateName(String name) throws HotelException {
		m=Pattern.compile("^[A-Z]([a-z]){3,}$").matcher(name);
		if(!m.find())
			throw new  HotelException("Name is not matching");
		return true;
	}

	@Override
	public boolean validateMob(String mob) throws HotelException {
		m=Pattern.compile("^[6789]([0-9]){9}$").matcher(mob);
		if(!m.find())
			throw new HotelException("This number is not valid");
		return true;
	}

	
	}

	



	
	
	
	

	