package com.capgemini.hotel.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelException;
import com.capgemini.hotel.util.Hotelutil;




public class CustomerBookingDAO implements ICustomerBookingDAO {

	Map<String,CustomerBean>customerDetails = new HashMap<String,CustomerBean>();

	@Override
	public boolean addCustomerDetails(CustomerBean bean) throws HotelException {
		customerDetails.put(bean.getCustomerid(), bean);
		System.out.println(bean.toString());
		System.out.println(
				"\n\nRoom has been successfullybooked and your customer id is " + bean.getCustomerid() + " Booked successfully at " +  bean.getDate());
		return true;
		
		
		
	}

	@Override
	public List<RoomBooking> roomDetails() throws HotelException {
		List<RoomBooking> RoomCategoryList = new ArrayList<>();
		for (Entry<String, String> man : Hotelutil.getRoomCategoryEntries().entrySet()) {
			RoomCategoryList.add(new RoomBooking(man.getKey(), man.getValue()));
		}
		return RoomCategoryList;

	}

	@Override
	public CustomerBean viewroomdetails(int id) {
		// TODO Auto-generated method stub
		 return  customerDetails.get((id+""));
	}
	
	
        
	
	
	
	
	
	
	
	
	
	
	
	
}
