package com.capgemini.hotel.dao;

import java.util.List;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelException;


public interface ICustomerBookingDAO {

	boolean addCustomerDetails(CustomerBean bean) throws HotelException ;
	
	public List<RoomBooking> roomDetails()throws HotelException;
	
	CustomerBean viewroomdetails(int id);
	
}
