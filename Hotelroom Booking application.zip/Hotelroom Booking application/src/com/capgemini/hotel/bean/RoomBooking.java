package com.capgemini.hotel.bean;

public class RoomBooking {

	private String roomid;
	private String roomtype;
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public String getRoomtype() {
		return roomtype;
	}
	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}
	public RoomBooking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RoomBooking(String roomid, String roomtype) {
		
		this.roomid = roomid;
		this.roomtype = roomtype;
	}
	@Override
	public String toString() {
		return "RoomBooking [roomid=" + roomid + ", roomtype=" + roomtype + "]";
	}
	
	
	
	
}
