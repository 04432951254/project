package com.capgemini.hotel.bean;

import java.time.LocalDate;

public class CustomerBean {
	
	private String name;
	private String mail;
	private String address;
	private String mob;
	private String customerid;
	private LocalDate date;
	
	
	public String getName() {
		return name;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMob() {
		return mob;
	}
	public void setMob(String mob) {
		this.mob = mob;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	
	
	public CustomerBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerBean(String name, String mail, String address, String mob) {
		super();
		this.name = name;
		this.mail = mail;
		this.address = address;
		this.mob = mob;
	}
	public CustomerBean(String name, String mob) {
		super();
		this.name = name;
		this.mob = mob;
	}
	@Override
	public String toString() {
		return "CustomerBean [name=" + name + ", mob=" + mob + "]";
	}
	
	
	
	
	}
	
	
	


