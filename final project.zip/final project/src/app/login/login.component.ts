import { Component, OnInit } from '@angular/core';
import { Login } from './../model/login.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginModel = new Login('', '');
  constructor(private router: Router) {}

  ngOnInit() {}

  onSubmit() {
    console.log("Submitted");
    console.log(this.loginModel.loginName);
    console.log(this.loginModel.password);
    if (
      this.loginModel.loginName == 'navshad' &&
      this.loginModel.password == 'roxx'
    ) {
      this.router.navigate(['list-emp']);
    }
    else {
      alert("invalid login, try again!");
    }
  }
}
