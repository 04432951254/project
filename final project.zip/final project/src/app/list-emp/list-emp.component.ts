import { Employee } from './../model/employee.model';

import { EmployeeService } from './../service/employee.service';

import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

// import { Employee } from '../model/employee.model';







@Component({

 selector: 'app-list-emp',

 templateUrl: './list-emp.component.html',

 styleUrls: ['./list-emp.component.css']

})

export class ListEmpComponent implements OnInit {

 employees: Employee[];

 addForm: any;

  baseUrl: string = 'http://localhost:3000/employees';





 constructor(private empservice: EmployeeService,private router: Router,) { }





 ngOnInit() {

  this.empservice.getEmployees()

  .subscribe((data: Employee[]) => {

  this.employees= data;

  });

 }

 deleteEmp(employee:Employee):void{



  this.empservice.deleteEmployees(employee.id)



  .subscribe(data=>{



   this.employees=this.employees.filter(emp=> emp !==employee);



  });

 }

 editEmp(employee: Employee): void {

  localStorage.removeItem('editEmpId');

  localStorage.setItem('editEmpId', employee.id.toString());

  this.router.navigate(['edit-emp']);

  }





  onSubmit() {



  console.log('Employee details sent to server!');



  this.empservice.createUser(this.addForm.value)



   .subscribe(data => {



   console.log("Data Saved!");



   },



   error => {



    console.log("Error occured " + error);



    //alert(error);



   });



  }



 }







