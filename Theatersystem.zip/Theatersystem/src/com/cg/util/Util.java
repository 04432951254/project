package com.cg.util;

import java.util.HashMap;
import java.util.Map;

public class Util {
	public static Map<String, String> viewAllTheatres = new HashMap<>();

	public static Map<String, String> getTicketCategoryEntries() {
		viewAllTheatres.put("tc001", "Sathyam");
		viewAllTheatres.put("tc002", "PVR");
		viewAllTheatres.put("tc003", "Inox");
		return viewAllTheatres;
	}
}
