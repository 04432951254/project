package com.cg.service;

import java.util.List;

import com.cg.bean.Theatre;
import com.cg.bean.Ticket;
import com.cg.tms.exception.TicketException;

public interface ITheatreService {
	boolean orderTicket(Ticket ticket) throws TicketException;

	public List<Theatre> viewAllTheatres();


	Ticket viewticket(int id);
}
