package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.bean.Theatre;
import com.cg.bean.Ticket;
import com.cg.dao.ITheatreDao;
import com.cg.dao.TheatreDao;
import com.cg.tms.exception.TicketException;

public class TheatreServiceImpl implements ITheatreService {
	ITheatreDao idao = null;

	@Override
	public boolean orderTicket(Ticket ticket) throws TicketException {
		ticket.setCustomerId(generateCustomerID());
		ticket.setDate(LocalDate.now());
		idao = new TheatreDao();
		return idao.orderTicket(ticket);
	}

	private String generateCustomerID() {
		return String.valueOf((int) (Math.random() * 10000));
	}

	@Override
	public List<Theatre> viewAllTheatres() {

		idao = new TheatreDao();
		return idao.viewAllTheatres();

	}

//	@Override
//	public List<Theatre> viewticket(int id) {
//		idao = new TheatreDao();
//		return idao.viewticket(id);
//	}

	@Override
	public Ticket viewticket(int id) {
		idao = new TheatreDao();
		return idao.viewticket(id);
	}

}
