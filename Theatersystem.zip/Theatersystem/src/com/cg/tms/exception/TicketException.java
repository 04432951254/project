package com.cg.tms.exception;


// creating custom user defined exception where the error message is hard coded by the developer
@SuppressWarnings("serial")
public class TicketException extends Exception {
	String s;
	public TicketException(String s) {
		this.s = s;
	}
	
	@Override
	public String toString() {
		return this.s;
	}
}
