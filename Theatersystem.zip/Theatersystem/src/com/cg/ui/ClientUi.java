package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.bean.Theatre;
import com.cg.bean.Ticket;
import com.cg.service.ITheatreService;
import com.cg.service.TheatreServiceImpl;
import com.cg.tms.exception.TicketException;




public class ClientUi {
	static Scanner scan = new Scanner(System.in);
 static  ITheatreService iser=null;
	public static Ticket r=null;

	public static void main(String[] args) {

		String h = null;

		do {

			System.out.println("Select the your option");
			System.out.println("1. Order Ticket\n 2.viewticket\n 3. Exit Id");
			int n = scan.nextInt();
			switch (n) {
			case 1:
				orderTicket();
				break;
			case 2:
				System.out.println("Enter the id");
				int id = scan.nextInt();
				Ticket r =viewticket(id);
				
				System.out.println("NAME of the customer : "+r.getCustName());
				System.out.println("Mobile number of the customer : "+r.getCustomerId());
				
				break;
		
			
			

			case 3:
				System.out.println("Program Terminated");
				System.exit(0);
				break;
			default:
				System.out.println("choose your proper choice from 1-3");
				n = scan.nextInt();
				break;
			}
			System.out.println("do you want to continue y/n");
			h = scan.next();
			if (h.equalsIgnoreCase(h)) {
				System.out.println("Program Terminated");
			}
		} while (h.equalsIgnoreCase("y"));

	}








	private static Ticket viewticket(int id) {
		ITheatreService iserv = null;
		iserv = new TheatreServiceImpl();
		return iserv.viewticket(id);
		
	
	
	}








	private static void getOrderDetails(int orderId) {
		// TODO Auto-generated method stub

	}

	private static void orderTicket() {
		String ticketCategoryID = "";
		ITheatreService iserv = null;
		iserv = new TheatreServiceImpl();
		List<Theatre> ticketCategoryList = iserv.viewAllTheatres();
		int n = 1;
		for (Theatre ticketCategoryName : ticketCategoryList) {
			System.out.println(String.valueOf(n) + ". " + ticketCategoryName);
			n++;
		}
		System.out.print("\nEnter option : ");
		try {
			switch (Integer.parseInt(scan.next().trim())) {
			case 1:
				ticketCategoryID = ticketCategoryList.get(0).getTheatreId();
				break;
			case 2:
				ticketCategoryID = ticketCategoryList.get(1).getTheatreId();
				break;
			case 3:
				ticketCategoryID = ticketCategoryList.get(2).getTheatreId();
				break;
			default:
				System.out.println("please enter the correct option");
				System.exit(-1); // Exits out of the application if wrong option is selected.
			}
		} catch (Exception e) {
			System.out.println("Enter only number");
			System.exit(-1); // Exits out of the application if char is entered instead of a number.
		}
		System.out.println("enter name");
		String custName = scan.next();
		System.out.println("enter phone");
		String phone = scan.next();

		Ticket ticket = new Ticket(custName, phone);

		iserv = new TheatreServiceImpl();
		try {
			iserv.orderTicket(ticket);
			
		} catch (TicketException e) {
			System.out.println(e);
		}
	}
}
