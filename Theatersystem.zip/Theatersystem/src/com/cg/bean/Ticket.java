package com.cg.bean;

import java.time.LocalDate;

public class Ticket {
	private String customerId;
	private String custName;
	private String phone;
	private LocalDate date;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public Ticket(String customerId, String custName, String phone, LocalDate date) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.phone = phone;
		this.date = date;

	}

	public Ticket() {
		super();
	}

	public Ticket(String custName, String phone) {
		super();
		this.custName = custName;
		this.phone = phone;

	}
	
	public String toString() {
		return "customerId: "+this.customerId+" customerName: "+this.custName;
	}

}
