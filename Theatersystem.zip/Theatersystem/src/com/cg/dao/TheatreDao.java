package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.bean.Theatre;
import com.cg.bean.Ticket;
import com.cg.tms.exception.TicketException;
import com.cg.util.Util;

public class TheatreDao implements ITheatreDao {
	static Map<String, Ticket> tMap = new HashMap<>();

	@Override
	public boolean orderTicket(Ticket ticket) throws TicketException {
		tMap.put(ticket.getCustomerId(), ticket);
		System.out.println(ticket.toString());
		System.out.println(
				"\n\nTicket Number " + ticket.getCustomerId() + " logged successfully at " + ticket.getDate());
		return true;
	}
	

	@Override
	public List<Theatre> viewAllTheatres() {
		List<Theatre> ticketCategoryList = new ArrayList<>();
		for (Entry<String, String> man : Util.getTicketCategoryEntries().entrySet()) {
			ticketCategoryList.add(new Theatre(man.getKey(), man.getValue()));
		}
		return ticketCategoryList;

	}
//	
//	@Override
//	public Ticket viewticket(int id) {
//		List<Theatre> ticketCategoryList = new ArrayList<>();
//		for (Entry<String, String> man : Util.getTicketCategoryEntries().entrySet()) {
//			ticketCategoryList.add(new Theatre(man.getKey(), man.getValue()));
//		}
//		return ticketCategoryList(id);
//
//	}

//
//	private Ticket ticketCategoryList(int id) {
//		// TODO Auto-generated method stub
//		return  tMap.get(id);
//	}


	@Override
	public Ticket viewticket(int id) {
		// TODO Auto-generated method stub
		 return  tMap.get((id+""));
	}

}
